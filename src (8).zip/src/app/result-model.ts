export class ResultModel {
    NAME: string;
    CATEGORY: string;
    CLIENT_ID : string;
    AMOUNT : number;
    MAX_AMOUNT: number;
    TRANSACTION_DATE:string;
    BILLING_PLACE:string;
}
